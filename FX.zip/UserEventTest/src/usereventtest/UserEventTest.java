
package usereventtest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Hasib
 */
public class UserEventTest extends Application implements EventHandler<ActionEvent> {
    
    Button button;
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("2 | Welcome");
        button=new Button("Okay");
        button.setOnAction(this);
        
        StackPane layout=new StackPane();
        layout.getChildren().add(button);
        
        Scene scene=new Scene(layout,600,400);
        
        primaryStage.setScene(scene);
        
        primaryStage.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void handle(ActionEvent e) {
        if(e.getSource()==button) {
            System.out.println("Button Pressed");
        }
    }
    
}
