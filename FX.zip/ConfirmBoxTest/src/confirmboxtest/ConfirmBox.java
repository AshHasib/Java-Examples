
package confirmboxtest;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ConfirmBox {
    
    
    public static boolean result;
    
    public static boolean display()
    {
        Stage window=new Stage();
        window.setTitle("Welcome");
        window.setMinWidth(300);
        window.initModality(Modality.APPLICATION_MODAL);
        
        
        Button yes=new Button("Yes");
        Button no=new Button("No");
        
        yes.setOnAction(e -> {
            //System.out.println("Yes button pressed");
            result=true;
            //window.close();
        });
        
        no.setOnAction(e -> {
            System.out.println("No button pressed");
            result=false;
            window.close();
        });
        
        Label label=new Label("Are you sure you want to quit?");
        
        VBox layout=new VBox();
        layout.getChildren().addAll(label,yes,no);
        
        layout.setAlignment(Pos.CENTER);
        Scene scene=new Scene(layout,300,250);
        window.setScene(scene);
        window.show();
        return result;
    }
}
