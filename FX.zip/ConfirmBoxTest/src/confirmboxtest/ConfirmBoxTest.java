
package confirmboxtest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author hasib
 */
public class ConfirmBoxTest extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Main Window");
        
        Button button=new Button("Press here!!!");
        
        button.setOnAction(e ->{
            
            boolean res=ConfirmBox.display();
            System.out.println(res);
        });
        
        StackPane layout=new StackPane();
        
        layout.getChildren().add(button);
        
        Scene scene=new Scene(layout,400,300);
        
        primaryStage.setScene(scene);
        
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
