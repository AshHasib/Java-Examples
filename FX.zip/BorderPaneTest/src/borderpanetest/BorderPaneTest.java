
package borderpanetest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author hasib
 */
public class BorderPaneTest extends Application {
    
    Stage window;
    
    @Override
    public void start(Stage primaryStage) {
        window=primaryStage;
        
        Button file=new Button("File");
        Button edit=new Button("Edit");
        Button tools=new Button("Tools");
        
        HBox top=new HBox();
        top.getChildren().addAll(file,edit,tools);
        
        Button New=new Button("New");
        Button refactor=new Button("Refactor");
        Button write=new Button("Write");
        
        VBox left=new VBox();
        left.getChildren().addAll(New,refactor,write);
        
        
        BorderPane layout=new BorderPane();
        layout.setTop(top);
        layout.setLeft(left);
        
        Scene scene=new Scene(layout, 400,300);
        
        window.setScene(scene);
        window.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
