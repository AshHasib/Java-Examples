
package gridpanetest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author hasib
 */
public class GridPaneTest extends Application {
    Stage window;
    @Override
    public void start(Stage primaryStage) {
        window=primaryStage;
        
        GridPane layout=new GridPane();
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.setVgap(8);
        layout.setHgap(10);
        
        Label lblName=new Label("Name:");
        TextField txtName=new TextField();
        txtName.setPromptText("ex. hasib");
        GridPane.setConstraints(lblName, 0, 0);
        GridPane.setConstraints(txtName, 1, 0);
        
        Label lblPassword=new Label("Password:");
        PasswordField txtPassword=new PasswordField();
        txtPassword.setPromptText("ex. 1234");
        GridPane.setConstraints(lblPassword, 0, 1);
        GridPane.setConstraints(txtPassword, 1, 1);
        
        Button submit=new Button("Submit");
        GridPane.setConstraints(submit, 1, 2);
        
        layout.getChildren().addAll(lblName,txtName,lblPassword,txtPassword,submit);
        
        Scene scene=new Scene(layout, 300,200);
        
        window.setScene(scene);
        
        window.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
