
package choiceboxtest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author hasib
 */
public class ChoiceBoxTest extends Application {
    Stage window;
    @Override
    public void start(Stage primaryStage) {
        window=primaryStage;
        
        ChoiceBox<String> box=new ChoiceBox<>();
        box.getItems().addAll("English","French","Bengali","Portugeese");
        box.setValue("English");
        box.getSelectionModel().selectedItemProperty().addListener((v,old,New)-> {
            System.out.println(New);
        });
        
        
        VBox layout=new VBox();
        //layout.setPadding(new Insets(30,30,30,30));
        layout.getChildren().add(box);
        layout.setAlignment(Pos.CENTER);
        
        
        Button button=new Button("Check");
        button.setOnAction(e ->{
            String language=box.getValue();
            System.out.println(language);
        });
        
        layout.getChildren().add(button);
        
        Scene scene=new Scene(layout,400,300);
        window.setScene(scene);
        window.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
