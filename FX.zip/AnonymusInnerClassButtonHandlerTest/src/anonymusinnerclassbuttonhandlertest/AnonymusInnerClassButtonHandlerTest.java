/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package anonymusinnerclassbuttonhandlertest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Hasib
 */
public class AnonymusInnerClassButtonHandlerTest extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("4| Welcome");
       
        Button button =new Button ("Click Here");
        
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("This is functioned by anonymus inner class");
            }
        });
        
        StackPane layout=new StackPane();
        layout.getChildren().add(button);
        
        Scene scene=new Scene(layout,600,400);
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
