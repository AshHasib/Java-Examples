
package lambdaexpressionbuttonhandletest;

import java.util.Stack;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Hasib
 */
public class LambdaExpressionButtonHandleTest extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("5| Welcome");
        Button button=new Button("Click Here");
        
        button.setOnAction((ActionEvent e) -> {
            System.out.println("This is functioned using lambda expression");
        });
        
        StackPane layout=new StackPane();
        
        layout.getChildren().add(button);
        
        Scene scene=new Scene(layout,600,400);
        
        primaryStage.setScene(scene);
        
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
