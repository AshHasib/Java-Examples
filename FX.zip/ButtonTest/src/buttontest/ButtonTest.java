/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buttontest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Hasib
 */
public class ButtonTest extends Application implements EventHandler<ActionEvent>{
    
    Button button1;
    static int counter=0;
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("3|Welcome");
        button1=new Button ("Start");
        button1.setOnAction(this);
        //button2=new Button("Exit");
        StackPane layout=new StackPane();
        
        layout.getChildren().add(button1);
        //layout.getChildren().add(button2);
        
        Scene scene=new Scene(layout, 600,400);
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void handle(ActionEvent event) {
        
        if(event.getSource()==button1 ) {
            if(counter%2==0) {
                button1.setText("Stop");
            }
            else {
                button1.setText("Start");
            }
            counter++;
        }
        
    }
    
}
